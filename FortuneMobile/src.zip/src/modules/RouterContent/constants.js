export const REDUCER_KEY = 'router';
export const SCENE_UPDATE = 'SCENE_UPDATE';
