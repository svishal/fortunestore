const config = {
  API_URL: 'https://fortunestore.herokuapp.com/api/v1',
};
export default config;
